import numpy as np
from tqdm import tqdm
import pandas as pd

import torch
import torch.nn as nn
from torch.optim import lr_scheduler

import pytorch_lightning as pl
from sentence_transformers import SentenceTransformer
import transformers
from typing import List, Dict, Tuple, Iterable, Type
import tokenizers
from transformers import AdamW
from transformers import get_linear_schedule_with_warmup

from sklearn.metrics import roc_auc_score

class SBERT(SentenceTransformer):
    def __init__(self, model_name_or_path: str = None, device: str = None):
        super().__init__(model_name_or_path, device=device)
        print(f'Using device {self.device}')

    def smart_batching_collate(self, batch):
        """
        Transforms a batch from a SmartBatchingDataset to a batch of tensors for the model
        :param batch:
            a batch from a SmartBatchingDataset
        :return:
            a batch of tensors for the model
        """
        num_texts = len(batch[0][0])

        labels = []
        paired_texts = [[] for _ in range(num_texts)]
        max_seq_len = [0] * num_texts
        for tokens, label in batch:
            labels.append(label)
            for i in range(num_texts):
                paired_texts[i].append(tokens[i])
                max_seq_len[i] = max(max_seq_len[i], len(tokens[i]))

        features = []
        for idx in range(num_texts):
            max_len = max_seq_len[idx]
            feature_lists = {}

            for text in paired_texts[idx]:
                sentence_features = self.get_sentence_features(text, max_len)

                for feature_name in sentence_features:
                    if feature_name not in feature_lists:
                        feature_lists[feature_name] = []

                    feature_lists[feature_name].append(sentence_features[feature_name])


            for feature_name in feature_lists:
                feature_lists[feature_name] = torch.cat(feature_lists[feature_name])

            features.append(feature_lists)

        return {'features': features, 'labels': torch.stack(labels)}

    def fit(self,
            train_objective: Iterable[Tuple[torch.utils.data.DataLoader, torch.nn.Module]],
            #evaluator: SentenceEvaluator,
            epoches: int = 1,
            steps_per_epoch = None,
            scheduler: str = 'WarmupLinear',
            warmup_steps: int = 10000,
            optimizer_class: Type[torch.optim.Optimizer] = transformers.AdamW,
            optimizer_params : Dict[str, object ]= {'lr': 2e-5, 'eps': 1e-6, 'correct_bias': False},
            weight_decay: float = 0.01,
            evaluation_steps: int = 0,
            output_path: str = None,
            save_best_model: bool = True,
            max_grad_norm: float = 1,
            local_rank: int = -1
            ):
        """
        Train the model with the given training objective
        Each training objective is sampled in turn for one batch.
        We sample only as many batches from each objective as there are in the smallest one
        to make sure of equal training with each dataset.
        :param weight_decay:
        :param scheduler:
        :param warmup_steps:
        :param optimizer:
        :param evaluation_steps:
        :param output_path:
        :param save_best_model:
        :param max_grad_norm:
        :param local_rank:
        :param train_objectives:
            Tuples of DataLoader and LossConfig
        :param evaluator:
        :param epochs:
        :param steps_per_epoch: Train for x steps in each epoch. If set to None, the length of the dataset will be used
        """
        train_loader, loss_model = train_objective

        param_optimizer = list(self.named_parameters())

        #init optimizer and sheduler
        if steps_per_epoch is None or steps_per_epoch == 0:
            steps_per_epoch = len(train_loader)

        no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
        optimizer_grouped_parameters = [
            {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)], 'weight_decay': weight_decay},
            {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
        ]
        t_total = int(steps_per_epoch * epoches)
        if local_rank != -1:
            t_total = t_total // torch.distributed.get_world_size()

        optimizer = optimizer_class(optimizer_grouped_parameters, **optimizer_params)
        scheduler = self._get_scheduler(optimizer, scheduler=scheduler, warmup_steps=warmup_steps, t_total=t_total)

        train_loader.collate_fn = self.smart_batching_collate
        
        for ep in range(1, epoches+1):
            self.train()
            iterator = tqdm(train_loader, desc=f'Epoch {ep}', total=len(train_loader))
            batch_loss = []
            for batch in iterator:
                self.zero_grad()

                batch = batch_to_device(batch, self.device)

                #get embeddings
                seqs = [self(sentence_feature)['sentence_embedding'] for sentence_feature in batch[0]]
                seq_a, seq_b = seqs
                #pass them to the loss function
                loss_value = loss_model(seq_a, seq_b, batch[1])
                loss_value.backward()

                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()

                batch_loss.append(loss_value.item())
                iterator.desc = f'Epoch {ep} Loss {sum(batch_loss)/len(batch_loss):.3}'

class ModelClass(pl.LightningModule):
    def __init__(self, hparams):
        super(ModelClass, self).__init__()
        self.hparams = hparams
        #define model layers
        self.bert = SBERT(hparams.model_path)
        self.drop = nn.Dropout(hparams.dropout_prob)
        self.lin = nn.Linear(self.bert[2].linear.out_features, hparams.num_classes)
        #define loss, metric and softmax
        self.soft = nn.Softmax(dim=1)
        self.loss_fn = nn.CrossEntropyLoss(weight=hparams.weigths, ignore_index=0) #ignoring PAD index
        self.auc = roc_auc_score
    
    def forward(self, input):
        #get sentence embeddings
        embs = self.bert(input)['sentence_embedding']

        logits = self.lin(self.drop(embs))

        return logits
    
    def prepare_data(self):
        df_train = pd.read_parquet(self.hparams.train_file_path)
        df_val = pd.read_parquet(self.hparams.val_file_path)

        self.train_ds = DatasetClass(features=df_train['question'].to_numpy(), target=df_train.drop('question', axis=1).to_numpy(), model=self.bert)
        self.val_ds = DatasetClass(features=df_val['question'].to_numpy(), target=df_val.drop('question', axis=1).to_numpy(), model=self.bert)

        self.num_train_steps = int(len(self.train_ds) / self.hparams.train_batch_size * self.hparams.num_epochs)
    
    def train_dataloader(self):
        loader = torch.utils.data.DataLoader(self.train_ds, collate_fn=self.smart_batching_collate,
                                             batch_size=self.hparams.train_batch_size,
                                             num_workers=4, shuffle=True)
        return loader
     
    def val_dataloader(self):
        loader = torch.utils.data.DataLoader(self.val_ds, collate_fn=self.smart_batching_collate,
                                             batch_size=self.hparams.valid_batch_size,
                                             num_workers=4)      
        return loader
    
    def training_step(self, batch, batch_idx):
        x, y = batch
        
        preds = self(x)
        loss = self.loss_fn(preds, y)
        
        logs = {'train_loss': loss}
        
        return {'loss': logs['train_loss'], 'log': logs, 'labels': y, 'preds': preds}
    
    def training_epoch_end(self, outputs):
        avg_loss = torch.stack([x['loss'] for x in outputs]).mean()

        label = torch.cat([x['labels'] for x in outputs], dim=0)
        preds = torch.cat([x['preds'] for x in outputs], dim=0)
        #label = np.eye(self.hparams.num_classes, dtype=np.int)[label.cpu().numpy()]
        auc = torch.tensor(self.auc(label.cpu().numpy(), self.soft(preds).detach().cpu(), average='macro', multi_class='ovo'))

        logs = {'train_epoch_loss': avg_loss, 'train_epoch_auc': auc}
        return {'log': logs}
    
    def validation_step(self, batch, batch_nb):
        x, y = batch
        
        preds = self(x)
        loss = self.loss_fn(preds, y)
        
        logs = {'val_loss': loss}
        
        return {'val_loss': logs['val_loss'], 'labels': y, 'preds': preds}
    
    def validation_epoch_end(self, outputs):
        avg_loss = torch.stack([x['val_loss'] for x in outputs]).mean()
        
        label = torch.cat([x['labels'] for x in outputs], dim=0)
        preds = torch.cat([x['preds'] for x in outputs], dim=0)
        #label = np.eye(self.hparams.num_classes, dtype=np.int)[label.cpu().numpy()]
        try:
          auc = torch.tensor(self.auc(label.cpu().numpy(), self.soft(preds).detach().cpu(), average='macro', multi_class='ovo'))
        except ValueError:
          auc = torch.tensor(0)

        logs = {'val_epoch_loss': avg_loss, 'val_epoch_auc': auc}
        return {'val_epoch_auc': logs['val_epoch_auc'], 'log': logs}
    
    def configure_optimizers(self):
        param_optimizer = list(self.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        optimizer_parameters = [
            {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)], 'weight_decay': 0.001},
            {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0},
        ]
        optimizer = AdamW(optimizer_parameters, lr=self.hparams.lr)
        scheduler = get_linear_schedule_with_warmup(optimizer, 
                                                    num_warmup_steps=0, 
                                                    num_training_steps=self.num_train_steps)
        
        return [optimizer], [scheduler]

    def predict(self, input, batch_size=32):
        ds = DatasetClass(features=input, target=np.zeros((len(input), 10)), model=self.bert)
        loader = torch.utils.data.DataLoader(ds, collate_fn=self.smart_batching_collate, batch_size=batch_size, num_workers=4)

        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.to(device)
        preds = []
        with torch.no_grad():
            for batch in tqdm(loader, total=len(loader), desc=f"Predicting on {device}"):
                features = batch[0]
                #move to proper device
                for feature_name in features:
                    features[feature_name] = features[feature_name].to(device)

                preds.append(self.soft(self(features)))
            
            preds = torch.cat(preds, dim=0)
        return preds

    def smart_batching_collate(self, batch):
        """
        Transforms a batch from a SmartBatchingDataset to a batch of tensors for the model
        :param batch:
            a batch from a SmartBatchingDataset
        :return:
            a batch of tensors for the model
        """
        labels = []
        texts = []
        max_len = 0
        for tokens, label in batch:
            labels.append(label)
            texts.append(tokens)
            max_len = max(max_len, len(tokens))

        features = []
        feature_lists = {}

        for text in texts:
            sentence_features = self.bert.get_sentence_features(text, max_len)

            for feature_name in sentence_features:
                if feature_name not in feature_lists:
                    feature_lists[feature_name] = []

                feature_lists[feature_name].append(sentence_features[feature_name])

        for feature_name in feature_lists:
            feature_lists[feature_name] = torch.cat(feature_lists[feature_name])

        features.append(feature_lists)

        return feature_lists, torch.argmax(torch.tensor(labels, dtype=torch.long), dim=1)

class DatasetClass(torch.utils.data.Dataset):
    """
    Dataset for smart batching, that is each batch is only padded to its longest sequence instead of padding all
    sequences to the max length.
    The SentenceBertEncoder.smart_batching_collate is required for this to work.
    SmartBatchingDataset does *not* work without it.
    """
    def __init__(self, features: np.array, target: np.array, model: SBERT, show_progress_bar: bool = True):
        """
        Create a new SentencesDataset with the tokenized texts and the labels as Tensor
        """
        self.show_progress_bar = show_progress_bar
        
        self.convert_input_examples(features, target, model)

    def convert_input_examples(self, texts: np.array, targets: np.array, model: SBERT):
        """
        Converts input examples to a SmartBatchingDataset usable to train the model with
        SentenceTransformer.smart_batching_collate as the collate_fn for the DataLoader
        smart_batching_collate as collate_fn is required because it transforms the tokenized texts to the tensors.
        :param examples:
            the input examples for the training
        :param model
            the Sentence BERT model for the conversion
        :return: a SmartBatchingDataset usable to train the model with SentenceTransformer.smart_batching_collate as the collate_fn
            for the DataLoader
        """
        num_texts = len(texts)
        inputs = []
        too_long = [0] * num_texts
        iterator = texts
        max_len = model.get_max_seq_length()

        if self.show_progress_bar:
            iterator = tqdm(iterator, desc="Convert dataset")

        for text in iterator:
            tokenized_texts = model.tokenize(text)
            """
            padding_length = max_len - len(tokenized_texts)
            if padding_length > 0:
                tokenized_texts = tokenized_texts + ([0] * padding_length)
            """
            inputs.append(tokenized_texts)    

        print('')
        print("Sentences longer than max_sequence_length: {}".format(sum(too_long)))

        self.tokens = inputs
        self.labels = targets

    def __getitem__(self, item):
        return self.tokens[item], self.labels[item]

    def __len__(self):
        return len(self.tokens)
