import os
import torch
from argparse import Namespace

def get_config(workdir=None, num_classes=None, weigths=0, batch_size=16):
    return Namespace(num_epochs = 5,
                    train_batch_size = 64,
                    valid_batch_size = 16,
                    dropout_prob=0.1,
                    num_classes=num_classes,
                    lr=3e-5,
                    weigths=torch.tensor(weigths),
                    model_path = 'distiluse-base-multilingual-cased',
                    train_file_path = os.path.join(workdir, 'data/train.parquet'),
                    val_file_path = os.path.join(workdir, 'data/val.parquet')
                    )