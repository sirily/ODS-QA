import os
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np 

from sklearn.metrics import roc_auc_score, confusion_matrix

def evaluate(model, workdir, run_name):
    test = pd.read_parquet(os.path.join(workdir, 'data/test.parquet'))
    annos = test.columns[1:]
    features, labels = test['question'].to_numpy(), test.drop('question', axis=1).to_numpy()
    del test

    preds_probas = model.predict(features)
    labels_max = np.argmax(labels, axis=1)
    preds = np.argmax(preds_probas.cpu().numpy(), axis=1)
    #compute cm
    cm = confusion_matrix(labels_max, preds, normalize='true')
    #sort it
    sorting_idx = np.argsort(np.diag(cm))[::-1]
    sorted_cm = cm[sorting_idx,:][:,sorting_idx]
    sorted_annos = []
    for id in sorting_idx:
        sorted_annos.append(annos[id])
    #plot heatmap
    fig, ax = plt.subplots(figsize=(20,20))
    ax = sns.heatmap(sorted_cm, vmax=1, xticklabels=sorted_annos, yticklabels=sorted_annos)
    fig.savefig(f"drive/My Drive/Colab Notebooks/{run_name}_heatmap.svg")
    #print metric
    auc = roc_auc_score(labels_max, preds_probas, average='macro', multi_class='ovo')
    print(f'Macro ROC-AUC = {auc}')