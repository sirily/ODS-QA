import pickle
import os
from source import config, train, eval
from source.model import ModelClass, DatasetClass

RUN_NAME = 'DeepPavlov ru-SBERT'

if __name__ == "__main__":
    workdir = os.path.dirname(__file__)
    with open(os.path.join(workdir, 'data/label_weights.pkl'), 'rb') as f:
        class_weights = pickle.load(f)
    config = config.get_config(workdir, num_classes=len(class_weights), weigths=list(class_weights.values()))
    model = train.run_training(ModelClass, config, run_name=RUN_NAME)
    eval.evaluate(model, workdir, RUN_NAME)