import numpy as np
from tqdm import tqdm
import pandas as pd

import torch
import torch.nn as nn
from torch.optim import lr_scheduler

import pytorch_lightning as pl
import transformers
import tokenizers
from transformers import AdamW
from transformers import get_linear_schedule_with_warmup

from sklearn.metrics import roc_auc_score

class ModelClass(pl.LightningModule):
    def __init__(self, hparams):
        super(ModelClass, self).__init__()
        self.hparams = hparams
        #define model layers
        self.bert = transformers.BertModel.from_pretrained(hparams.model_path)
        self.drop = nn.Dropout(hparams.dropout_prob)
        self.lin = nn.Linear(self.bert.pooler.dense.out_features, hparams.num_classes)
        #define loss, metric and softmax
        self.soft = nn.Softmax(dim=1)
        self.loss_fn = nn.CrossEntropyLoss(weight=hparams.weigths, ignore_index=0) #ignoring PAD index
        self.auc = roc_auc_score
    
    def forward(self, input):
        #get sentence embeddings
        embs = self.bert(input_ids=input['input_ids'], attention_mask=input['attention_mask'], token_type_ids=input['token_type_ids'])[1]
        logits = self.lin(self.drop(embs))

        return logits
    
    def prepare_data(self):
        df_train = pd.read_parquet(self.hparams.train_file_path)
        df_val = pd.read_parquet(self.hparams.val_file_path)

        self.train_ds = DatasetClass(features=df_train['question'].to_numpy(), target=df_train.drop('question', axis=1).to_numpy(), 
                                         tokenizer_path=self.hparams.tokenizer_path)
        self.val_ds = DatasetClass(features=df_val['question'].to_numpy(), target=df_val.drop('question', axis=1).to_numpy(), 
                                       tokenizer_path=self.hparams.tokenizer_path)

        self.num_train_steps = int(len(self.train_ds) / self.hparams.batch_size * self.hparams.num_epochs)
    
    def train_dataloader(self):
        loader = torch.utils.data.DataLoader(self.train_ds, collate_fn=self.train_ds.collate_fn,
                                             batch_size=self.hparams.batch_size,
                                             num_workers=4, shuffle=True)
        return loader
     
    def val_dataloader(self):
        loader = torch.utils.data.DataLoader(self.val_ds, collate_fn=self.train_ds.collate_fn,
                                             batch_size=self.hparams.batch_size,
                                             num_workers=4)      
        return loader
    
    def training_step(self, batch, batch_idx):
        x, y = batch
        
        preds = self(x)
        loss = self.loss_fn(preds, y)
        
        logs = {'train_loss': loss}
        
        return {'loss': logs['train_loss'], 'log': logs}
    
    def training_epoch_end(self, outputs):
        avg_loss = torch.stack([x['loss'] for x in outputs]).mean()

        logs = {'train_epoch_loss': avg_loss}
        return {'log': logs}
    
    def validation_step(self, batch, batch_nb):
        x, y = batch
        
        preds = self(x)
        loss = self.loss_fn(preds, y)
        
        logs = {'val_loss': loss}
        self.logger.experiment.log(logs)
        
        return {'val_loss': logs['val_loss'], 'labels': y, 'preds': preds}
    
    def validation_epoch_end(self, outputs):
        avg_loss = torch.stack([x['val_loss'] for x in outputs]).mean()

        label = torch.cat([x['labels'] for x in outputs], dim=0)
        preds = torch.cat([x['preds'] for x in outputs], dim=0)
        label = np.eye(self.hparams.num_classes, dtype=np.int)[label.cpu().numpy()]
        try:
          auc = torch.tensor(self.auc(label, self.soft(preds).cpu().numpy(), average='macro', multi_class='ovo'))
        except ValueError:
          auc = torch.tensor(0)

        logs = {'val_epoch_loss': avg_loss, 'val_epoch_auc': auc}
        return {'val_epoch_auc': logs['val_epoch_auc'], 'log': logs}
    
    def configure_optimizers(self):
        param_optimizer = list(self.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        optimizer_parameters = [
            {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)], 'weight_decay': 0.001},
            {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0},
        ]
        optimizer = AdamW(optimizer_parameters, lr=self.hparams.lr)
        scheduler = get_linear_schedule_with_warmup(optimizer, 
                                                    num_warmup_steps=0, 
                                                    num_training_steps=self.num_train_steps)
        
        return [optimizer], [scheduler]

    def predict(self, texts, batch_size=12):
        ds = DatasetClass(features=texts, target=np.zeros((len(texts), 2)), tokenizer_path=self.hparams.tokenizer_path)
        loader = torch.utils.data.DataLoader(ds, collate_fn=ds.collate_fn, batch_size=batch_size, num_workers=4)

        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.to(device)
        preds = []
        with torch.no_grad():
            for batch in tqdm(loader, total=len(loader), desc=f"Predicting on {device}"):
                features = batch[0]
                #move to proper device
                for feature_name in features:
                    features[feature_name] = features[feature_name].to(device)

                preds.append(self.soft(self(features)))
            
            preds = torch.cat(preds, dim=0)
        return preds


class DatasetClass(torch.utils.data.Dataset):
    """
    Dataset for smart batching, that is each batch is only padded to its longest sequence instead of padding all
    sequences to the max length.
    The SentenceBertEncoder.smart_batching_collate is required for this to work.
    SmartBatchingDataset does *not* work without it.
    """
    def __init__(self, features: np.array, target: np.array, tokenizer_path: str, show_progress_bar: bool = True):
        """
        Create a new SentencesDataset with the tokenized texts and the labels as Tensor
        """
        self.show_progress_bar = show_progress_bar
        self.tokenizer = transformers.AutoTokenizer.from_pretrained(tokenizer_path)
        self.features = self.make_tokens(features)
        self.target = target

    def make_tokens(self, texts):
        tokens = []
        for text in tqdm(texts, desc='Tokenizing...'):
            tokens.append(self.tokenizer.encode_plus(text))

        return tokens

    def collate_fn(self, batch):
        """
        Transforms a batch from a SmartBatchingDataset to a batch of tensors for the model
        :param batch:
            a batch from a SmartBatchingDataset
        :return:
            a batch of tensors for the model
        """
        tokens, labels = [], []
        for token, label in batch:
            tokens.append(token)
            labels.append(label)

        max_len = 0
        for token in tokens:
            max_len = max(max_len, len(token['input_ids']))
        
        for token in tokens:
            padding_length = max_len - len(token['input_ids'])
            if padding_length > 0:
                token['input_ids']= token['input_ids'] + ([0] * padding_length)
                token['attention_mask'] = token['attention_mask'] + ([0] * padding_length)
                token['token_type_ids'] = token['token_type_ids'] + ([0] * padding_length)

            token['input_ids'] = torch.tensor(token['input_ids'])
            token['attention_mask'] = torch.tensor(token['attention_mask'])
            token['token_type_ids'] = torch.tensor(token['token_type_ids'])

        tokens_dict = {}
        for token in tokens:
            for key in token:
                #if key not present in dict
                #add it with an empty list
                if key not in tokens_dict:
                    tokens_dict[key] = []

                tokens_dict[key].append(token[key])

        #stack all lists
        for key in tokens_dict:
            tokens_dict[key] = torch.stack(tokens_dict[key])

        return tokens_dict, torch.argmax(torch.tensor(labels, dtype=torch.long), dim=1)

    def __getitem__(self, item):
        return self.features[item], self.target[item]

    def __len__(self):
        return len(self.features)