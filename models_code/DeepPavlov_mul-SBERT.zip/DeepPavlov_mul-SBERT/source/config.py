import torch

import os
from argparse import Namespace

def get_config(workdir=None, num_classes=None, weigths=0, batch_size=16):
    return Namespace(num_epochs = 5,
                    batch_size = batch_size,
                    dropout_prob=0.1,
                    num_classes=num_classes,
                    lr=3e-5,
                    weigths=torch.tensor(weigths),
                    model_path = "DeepPavlov/bert-base-multilingual-cased-sentence",
                    tokenizer_path = "DeepPavlov/bert-base-multilingual-cased-sentence",
                    train_file_path = os.path.join(workdir, 'data/train.parquet'),
                    val_file_path = os.path.join(workdir, 'data/val.parquet')
    )