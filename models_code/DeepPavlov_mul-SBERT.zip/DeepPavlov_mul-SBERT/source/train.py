import wandb
import os

from pytorch_lightning import Trainer
from pytorch_lightning.loggers import WandbLogger
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping 

def run_training(model_class, config, project_name='ODS_QA', run_name='test'):
    model = model_class(config)

    wandb_logger = WandbLogger(project=project_name, name=run_name)
    stop_patience = 2
    early_stopping = EarlyStopping(monitor='val_epoch_auc',
                                min_delta=0,
                                patience=stop_patience,
                                verbose=True,
                                mode='max')
    
    #ckpt_path = wandb_logger.experiment.dir
    ckpt_path = 'drive/My Drive/Colab Notebooks/checkpoints'
    checkpoint_callback = ModelCheckpoint(filepath=os.path.join(ckpt_path, run_name+'_{epoch}-{val_epoch_auc:.2f}'), 
                                        save_top_k=1, verbose= True,
                                        monitor='val_epoch_auc', mode='max')
    trainer = Trainer(gpus=1, early_stopping_callback=early_stopping, checkpoint_callback=checkpoint_callback, logger=wandb_logger, max_epochs=config.num_epochs)
    trainer.fit(model)
    for file in os.listdir(ckpt_path):
        if file.endswith(".ckpt"):
            ckpt_path = os.path.join(ckpt_path, file)
            model.load_from_checkpoint(ckpt_path)
            
    return model
